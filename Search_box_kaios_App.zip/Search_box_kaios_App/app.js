alert("ALL_BANK>JS");
window.addEventListener("load", function() {
  document.getElementById("myInput").focus();
});

window.addEventListener("input", function() {
  console.log("oninput");
  var input, filter, ul, li, a, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  ul = document.getElementById("myUL");
  li = ul.getElementsByTagName("li");
  for (i = 0; i < li.length; i++) {
    a = li[i].getElementsByTagName("a")[0];
    txtValue = a.textContent || a.innerText;
    if (txtValue.toUpperCase().indexOf(filter) > -1) {
      li[i].style.display = "";
    } else {
      li[i].style.display = "none";
    }
  }
});

// $("#myInput").on("keyup", function() {
//   console.log("key up");
// });

// document.getElementById("myInput").addEventListener("click", function(){
//   // code here
// });

// window.addEventListener("input", function() {
//   console.log("typing");
// });
